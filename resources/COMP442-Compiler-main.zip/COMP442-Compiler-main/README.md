# COMP442-Compiler
## Author: William Tarte
## Submitted to: Professor Joey Paquet in the context of COMP 442: Compiler Design Winter 2021
